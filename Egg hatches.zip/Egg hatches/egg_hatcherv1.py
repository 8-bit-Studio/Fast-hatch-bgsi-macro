import time
import os
import sys
from datetime import datetime

try:
    import pyautogui
    import pydirectinput
    import keyboard
    import winsound
    import cv2
    import numpy as np
    from PIL import Image
except ImportError as e:
    print(f"\nMissing dependency: {e.name}")
    print("Run: pip install pyautogui pydirectinput keyboard Pillow opencv-python numpy")
    input("\nPress Enter to exit...")
    sys.exit()

# ─── Config ─────────────────────────────────────────────────────────────
VERSION = "V1.1"
COOLDOWN_SECONDS = 15
SCALES = (0.95, 1.0, 1.05)
THRESHOLD = 0.85

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
SECRET_PATH = os.path.join(SCRIPT_DIR, "secret_tag.png")
INFINITY_PATH = os.path.join(SCRIPT_DIR, "Infinity_tag.png")

# ─── Visuals ────────────────────────────────────────────────────────────
def rainbow_text(text, bold=True):
    colors = [196, 202, 208, 226, 46, 51, 21, 93, 201]
    styled = ""
    for i, char in enumerate(text):
        color = colors[i % len(colors)]
        style = "\033[1m" if bold else ""
        styled += f"{style}\033[38;5;{color}m{char}"
    styled += "\033[0m"
    print(styled)

def play_alert():
    try:
        winsound.PlaySound("SystemAsterisk", winsound.SND_ALIAS)
    except:
        pass

# ─── Detection ──────────────────────────────────────────────────────────
def load_template(path):
    if not os.path.exists(path):
        return None
    return cv2.imread(path, cv2.IMREAD_GRAYSCALE)

def capture_screen_gray():
    try:
        screen = pyautogui.screenshot()
        screen_np = np.array(screen.convert("RGB"))
        return cv2.cvtColor(screen_np, cv2.COLOR_RGB2GRAY)
    except:
        return None

def match_template(screen_gray, template, scales=SCALES, threshold=THRESHOLD):
    if screen_gray is None or template is None:
        return False
    try:
        for scale in scales:
            resized = cv2.resize(template, None, fx=scale, fy=scale, interpolation=cv2.INTER_AREA)
            result = cv2.matchTemplate(screen_gray, resized, cv2.TM_CCOEFF_NORMED)
            if np.max(result) >= threshold:
                return True
    except:
        pass
    return False

# ─── Load Templates ─────────────────────────────────────────────────────
secret_tpl = load_template(SECRET_PATH)
infinity_tpl = load_template(INFINITY_PATH)

# ─── Main Loop ──────────────────────────────────────────────────────────
is_running = False
last_key = None
last_hit = {"secret": 0.0, "infinity": 0.0}
hatch_count = {"secret": 0, "infinity": 0}

# ─── Startup Banner ─────────────────────────────────────────────────────
print("=" * 60)
print(f"🐣 Auto Egg Hatcher {VERSION} By 8 Bit studio")
print("🎮 Controls: F1 = START | F2 = STOP")
print("=" * 60)
print(f"Secret pet total: {hatch_count['secret']}")
rainbow_text(f"Infinity pet total: {hatch_count['infinity']}", bold=True)

try:
    while True:
        # Toggle macro state
        if keyboard.is_pressed('f1') and last_key != 'f1':
            is_running = True
            last_key = 'f1'
            print("\n✅ Macro started.")
        elif keyboard.is_pressed('f2') and last_key != 'f2':
            is_running = False
            last_key = 'f2'
            print("\n🛑 Macro stopped.")

        if is_running:
            pydirectinput.press('e')
            screen_gray = capture_screen_gray()
            now = time.time()

            # Secret tag detection
            if now - last_hit["secret"] >= COOLDOWN_SECONDS and secret_tpl is not None:
                if match_template(screen_gray, secret_tpl):
                    last_hit["secret"] = now
                    hatch_count["secret"] += 1
                    timestamp = datetime.now().strftime("%I:%M %p")
                    rainbow_text(f"Secret hatched at {timestamp}!", bold=True)
                    play_alert()
                    print("\033[F\033[F", end="")  # Move up two lines
                    print(f"Secret pet total: {hatch_count['secret']}")
                    rainbow_text(f"Infinity pet total: {hatch_count['infinity']}", bold=True)

            # Infinity tag detection
            if now - last_hit["infinity"] >= COOLDOWN_SECONDS and infinity_tpl is not None:
                if match_template(screen_gray, infinity_tpl):
                    last_hit["infinity"] = now
                    hatch_count["infinity"] += 1
                    timestamp = datetime.now().strftime("%I:%M %p")
                    rainbow_text(f"INFINITY hatched at {timestamp}!", bold=True)
                    play_alert()
                    print("\033[F\033[F", end="")  # Move up two lines
                    print(f"Secret pet total: {hatch_count['secret']}")
                    rainbow_text(f"Infinity pet total: {hatch_count['infinity']}", bold=True)

        time.sleep(0.05)

except KeyboardInterrupt:
    pass

input("\nPress Enter to exit...")
